/*

    author: Fahad
    date: 3/1/2021

 */
package Mobile_Banking_System_Phase_1;

public class Main {
    public static void main(String [] args){

        User show_user = new User();
        show_user.show_account_details();

    }
}

